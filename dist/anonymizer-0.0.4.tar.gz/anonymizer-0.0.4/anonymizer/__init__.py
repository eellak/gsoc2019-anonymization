from anonymizer import matcher_patterns, trie_index, anonymize
